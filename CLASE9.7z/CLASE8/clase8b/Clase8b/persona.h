#ifndef PERSONA_H_INCLUDED
#define PERSONA_H_INCLUDED

typedef struct{
    int dia;
    int mes;
    int anio;
}eFecha;

typedef struct{
    int id;
    char descripcion[31];
}eNacion;

typedef struct{
    char apellido[31];
    char nombre[31];
    int edad;
    eFecha fechaNue;
    eNacion idNacionalidad;
    int isEmpty;
}ePersona;

#endif // PERSONA_H_INCLUDED

void init_pers(ePersona pers[], int CANT);
void alta_pers(ePersona pers[],int CANT);
void mostrarUno_pers(ePersona per);
void mostrarTodos_pers(ePersona pers[],int CANT);
void ordenar_pers(ePersona pers[],int CANT);
void modificar_pers(ePersona pers[], int CANT);
void baja_pers(ePersona pers[],int CANT);

