#include <stdio.h>
#include <stdlib.h>
#include "persona.h"
#define CANT 3

//AGREGAR BAJA Y MODIFICACION

int main()
{
    int opcion;
    ePersona pers[CANT];
    eNacion nacionalidades[]={1,"Argentina",2,"Peru",3,"Uruguay"};
    init_pers(pers,CANT);

    do{

        printf("\n1)Alta\n2)Mostrar\n3)Modificar\n4)Baja\n5)Salir\n");
        scanf("%d",&opcion);

        switch(opcion){

            case 1:
                alta_pers(pers,CANT);
                break;
            case 2:
                ordenar_pers(pers,CANT);
                mostrarTodos_pers(pers,CANT);
                break;
            case 3:
                modificar_pers(pers,CANT);
                break;
            case 4:
                baja_pers(pers,CANT);
                break;
        }
    }while(opcion!=5);


    return 0;
}
