#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "persona.h"
#include "ctype.h"

//1 = VACIO

void init_pers(ePersona pers[], int CANT){

    int i;

    for(i=0;i<CANT;i++){

        pers[i].isEmpty = 1;
    }

}

void alta_pers(ePersona pers[], int CANT){

    int i;
    int j;

    for(i=0;i<CANT;i++){

        if(pers[i].isEmpty != 0){

            fflush(stdin);
            printf("Ingrese apellido: ");
            scanf("%s",pers[i].apellido);
            for(j = 0;pers[i].apellido; j++)
                pers[i].apellido[j] = toupper(pers[i].apellido[j]);

            fflush(stdin);
            printf("\nIngrese nombre: ");
            scanf("%s",pers[i].nombre);
            toupper(pers[i].nombre);

            printf("\nIngrese edad: ");
            scanf("%d",&pers[i].edad);

            printf("\nIngrese dia: ");
            scanf("%d",&pers[i].fechaNue.dia);

            printf("\nIngrese mes: ");
            scanf("%d",&pers[i].fechaNue.mes);

            printf("\nIngrese anio: ");
            scanf("%d",&pers[i].fechaNue.anio);

            pers[i].isEmpty = 0;
            printf("\n");

        }

    }

}

void mostrarUno_pers(ePersona per){

    printf("\n\n %s - %s - %d - %d",per.apellido,per.nombre,per.edad,per.isEmpty);
    printf("\nFecha: %d de %d del %d",per.fechaNue.dia,per.fechaNue.mes,per.fechaNue.anio);

    printf("\n");
}


void mostrarTodos_pers(ePersona pers[],int CANT){

    int i;

    for(i=0;i<CANT;i++){

        mostrarUno_pers(pers[i]);
    }
    printf("\n");
}

void ordenar_pers(ePersona pers[],int CANT){

    int i,j;
    ePersona aux;

    for(i=0;i<CANT-1;i++){

        for(j=i+1;j<CANT;j++){

            if(strcmp(pers[i].apellido,pers[j].apellido) > 0){

                aux = pers[i];
                pers[i] = pers[j];
                pers[j] = aux;
            }
        }
    }
}

void modificar_pers(ePersona pers[], int CANT){



}

void baja_pers(ePersona pers[],int CANT){}
