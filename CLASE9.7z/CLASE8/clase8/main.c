#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "persona.h"

ePersona per;

int main()
{
    per = ingreso(per);
    mostrar(per);

    return 0;
}
