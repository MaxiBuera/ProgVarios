#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "persona.h"

ePersona ingreso(ePersona per){

    fflush(stdin);
    printf("Ingrese apellido: ");
    scanf("%s",per.apellido);
    //gets(per.apellido);

    fflush(stdin);
    printf("\nIngrese nombre: ");
    scanf("%s",per.nombre);
    //gets(per.nombre);

    printf("\nIngrese edad: ");
    scanf("%d",&per.edad);

    per.isEmpty = 0;

    return per;
}

void mostrar(ePersona per){

    printf("\n\n%s - %s - %d - %d",per.apellido,per.nombre,per.edad,per.isEmpty);
}
