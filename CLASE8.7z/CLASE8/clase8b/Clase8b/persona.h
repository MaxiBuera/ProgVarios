#ifndef PERSONA_H_INCLUDED
#define PERSONA_H_INCLUDED

typedef struct{
    char apellido[31];
    char nombre[31];
    int edad;
    int isEmpty;
}ePersona;

#endif // PERSONA_H_INCLUDED

void init_pers(ePersona pers[], int CANT);
void alta_pers(ePersona pers[],int CANT);
void mostrarUno_pers(ePersona per);
void mostrarTodos_pers(ePersona pers[],int CANT);

