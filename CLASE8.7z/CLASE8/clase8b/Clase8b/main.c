#include <stdio.h>
#include <stdlib.h>
#include "persona.h"
#define CANT 3

//AGREGAR BAJA Y MODIFICACION

int main()
{

    //char opc;
    ePersona pers[CANT];

    init_pers(pers,CANT);

    alta_pers(pers,CANT);
    mostrarTodos_pers(pers, CANT);

    return 0;
}
