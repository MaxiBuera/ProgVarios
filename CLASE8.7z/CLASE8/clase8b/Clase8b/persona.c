#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "persona.h"

//1 = VACIO

void init_pers(ePersona pers[], int CANT){

    int i;

    for(i=0;i<CANT;i++){

        pers[i].isEmpty = 1;
    }

}

void alta_pers(ePersona pers[], int CANT){

    int i;

    for(i=0;i<CANT;i++){

        fflush(stdin);
        printf("Ingrese apellido: ");
        scanf("%s",pers[i].apellido);

        fflush(stdin);
        printf("\nIngrese nombre: ");
        scanf("%s",pers[i].nombre);

        printf("\nIngrese edad: ");
        scanf("%d",&pers[i].edad);

        pers[i].isEmpty = 0;
        printf("\n");
    }

}

void mostrarUno_pers(ePersona per){

    printf("\n\n %s - %s - %d - %d",per.apellido,per.nombre,per.edad,per.isEmpty);

    printf("\n");
}


void mostrarTodos_pers(ePersona pers[],int CANT){

    int i;

    for(i=0;i<CANT;i++){

        mostrarUno_pers(pers[i]);
    }
    printf("\n");
}


